<?php
$connect = mysqli_connect('localhost','apelsif3_vkr','eaJ6415263', 'apelsif3_vkr') or die ("error connect to database");