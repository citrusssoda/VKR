<?php
session_start();
if(isset($_SESSION['user'])){
    header('location: /');
}
?>
<html>
<head>
<meta charset="utf-8">
    <title>Главная</title>  
    <link rel="stylesheet" href="style.css">
    <?php require_once 'header.php';?>
</head>
<body>
    <div class="w-50 p-3 mx-auto my-3" style="background-color: #eee;">
    <h2 class="text-center">Регистрация</h2><hr>

    <div class="mx-auto" style="width: 500px;">

    <form class="form-group"  action="signup.php" method="post">

  <div class="row ">
    <div class="col-6">
    <label>Логин*</lable>
<input type="text" class="form-control " name="login" placeholder="Придумайте логин" title="Логин для входа">
<label>Пароль*</lable>
<input type="password" class="form-control" name="password" placeholder="Придумайте пароль"  title="Пароль для входа">
<label>Повторите пароль*</lable>
<input type="password" class="form-control" name="password_repeat" placeholder="Повтор пароля"  title="Повтор пароля">
<label>e-mail*</lable>
<input type="email" class="form-control" name="email" placeholder="Придумайте логин" title="Логин для входа">
    </div>
    <div class="col-6">
    <label>Фамилия*</lable>   
    <input type="text" class="form-control " name="f_user" placeholder="Введите фамилию" title="Введите вашу фамилию">
<label>Имя*</lable>
<input type="text" class="form-control" name="i_user" placeholder="Введите имя" title="Введите ваше имя">
<label>Отчество</lable>
<input type="text" class="form-control" name="o_user" placeholder="Введите отчество" title="Введите ваше отчество">
<label>Дата рождения</lable>
<input type="date" class="form-control" name="date" placeholder="Выберите дату рождения" title="Выберите вашу дату рождения">
    </div>  </div>
    <button class="btn btn-dark" type="submit">Зарегистрируйтесь</button>
</form>
<p>Уже зарегестрированы?<a class="urll text-dark font-weight-bold"  href="index.php"> Авторизируйтесь!</a></p>
<p class="text-danger">* - обязательные поля</p>
 <?php
 if(isset($_SESSION['message'])){
     echo '    <p class="msg"> ' . $_SESSION['message'] . '</p>';
 }
 unset($_SESSION['message']);
    ?>
</div>
</div>
<?php require_once 'footer.php';?>
</body>
</html>