<?php
session_start();
unset($_SESSION['user']);
header('location: index.php');//выход
session_write_close();
mysqli_close($connect);