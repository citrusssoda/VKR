<?php
session_start(); //запуск сессии
require_once 'connect.php';
?><html>
<head>
<meta charset="utf-8">
    <title>Главная</title>  
    <link rel="stylesheet" href="style.css">
    <?php require_once 'header.php';?>
</head>
<body>
    <div class="w-75 p-3 mx-auto my-3" style="background-color: #eee;">
    <h2 class="text-center">Личный кабинет</h2>
    <hr><h4 class="text-center">Вы успешно зашли как — <?= $_SESSION['user']['f_user']?> <?= $_SESSION['user']['i_user']?> <?= $_SESSION['user']['o_user']?>!</h4>
    <hr>
    <?php
 if(isset($_SESSION['message'])){
     echo '    <p class="msg"> ' . $_SESSION['message'] . '</p>';
 }
 unset($_SESSION['message']);
    ?>
    <div class="row ">
    <div class="col-6">
    <p class="text-center">Список устройств:</p>
<?php 
$id_us = $_SESSION['user']['id_user'];
$sql = mysqli_query($connect, "SELECT `device`.photo_device AS photo_device, `device`.id_device AS id_device, `device`.name_device AS name_device, `connected`.id_device AS id_device, `connected`.date_when AS date_when, `connected`.status AS status FROM `device`,`connected` WHERE `connected`.id_user = '$id_us' and `connected`.id_device = `device`.id_device");
echo'<div class="row ">';
while($row = mysqli_fetch_array( $sql )) {  
    $show_img = base64_encode($row["photo_device"]);
  echo '<div class="col-6"><div class="card" style="width: 11rem;">
  <img class="card-img-top" src="data:image/jpeg;base64,'.$show_img.'"  alt="Card image cap">
  <div class="card-body">
    <h5 class="card-title">' ;
    echo $row['name_device'] ; 
    echo '</h5>       <p class="card-text">' ;
    echo $row['date_when'] ;
    echo '</p>   ' ;
    echo '<p class="card-text">' ;
    if($row['status']=='1'){
        echo 'включён </p>   ' ;
    }
    if($row['status']=='0'){
        echo 'выключен </p>   ' ;
    }
    echo '   </div>
    </div><br></div>' ;
} 
echo'</div>';
?>



    </div>
    <div class="col-6">
    <p class="text-center">Вкл/выкл устройства:</p>


    <form class="form-group ml-5 pl-5"  action="change_status.php" method="post">
    <div class="input-group">
  <select class="custom-select"  name="select_device" id="inputGroupSelect04" aria-label="Example select with button addon">
    <option selected>Выберите устройство...</option>
  <?php 
$id_us = $_SESSION['user']['id_user'];
$sql = mysqli_query($connect, "SELECT `device`.photo_device AS photo_device, `device`.id_device AS id_device, `device`.name_device AS name_device, `connected`.id_device AS id_device, `connected`.date_when AS date_when, `connected`.status AS status FROM `device`,`connected` WHERE `connected`.id_user = '$id_us' and `connected`.id_device = `device`.id_device");
while($row = mysqli_fetch_array( $sql )) {  
echo'<option value="'.$row['id_device'].'">'.$row['name_device'].'</option>';
}
  ?>
  </select>
  <div class="input-group-append">
    <button class="btn btn-outline-secondary" type="submit"><img src="https://cdn-icons-png.flaticon.com/512/91/91709.png" width="20"></button>
  </div>
</div>
<br>
</form>


<p class="text-center">Подключить устройство:</p>

<form class="form-group ml-5 pl-5"  action="add_connection.php" method="post">
    <div class="input-group">
  <select class="custom-select"  name="select_adddevice" id="inputGroupSelect04" aria-label="Example select with button addon">
    <option selected>Выберите устройство...</option>
  <?php 
$id_us = $_SESSION['user']['id_user'];
$sql = mysqli_query($connect, "SELECT * FROM  `device`");
while($row = mysqli_fetch_array( $sql )) {  
echo'<option value="'.$row['id_device'].'">'.$row['name_device'].'</option>';
}
  ?>
  </select>
  <div class="input-group-append">
    <button class="btn btn-outline-secondary" type="submit">Добавить</button>
  </div>
</div>
<br>
</form>

</div>  </div>


</div>
<?php require_once 'footer.php';?>
</body>
</html>