<?php
session_start(); //запуск сессии
require_once 'connect.php';
//подключение к БД

$select_adddevice=$_POST['select_adddevice'];
$id_us = $_SESSION['user']['id_user'];

$sql = "INSERT INTO connected (`id_connected`, `id_user`, `id_device`, `date_when`,  `status`) VALUES (NULL, '$id_us', '$select_adddevice', NULL, '0')";
    $res = mysqli_query($connect, $sql) or die ("Ошибка". mysqli_error($connect));   
    $_SESSION['message']="Устройство подключено!";//вывод сообщения
    header('location: polz.php');//Вернуться к вход

?>

