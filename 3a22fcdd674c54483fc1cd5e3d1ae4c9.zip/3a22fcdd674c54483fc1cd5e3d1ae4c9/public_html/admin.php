<?php
session_start(); //запуск сессии
require_once 'connect.php';
?><html>
<head>
<meta charset="utf-8">
    <title>Главная</title>  
    <link rel="stylesheet" href="style.css">
    <?php require_once 'header.php';?>
</head>
<body>
    <div class="w-75 p-3 mx-auto my-3" style="background-color: #eee;">
    <h2 class="text-center">Админ-панель</h2>
    <hr><h4 class="text-center">Вы успешно зашли как — <?= $_SESSION['user']['f_user']?> <?= $_SESSION['user']['i_user']?> <?= $_SESSION['user']['o_user']?>!</h4>
    <hr>
    <?php
 if(isset($_SESSION['message'])){
     echo '    <p class="msg"> ' . $_SESSION['message'] . '</p>';
 }
 unset($_SESSION['message']);
    ?>
    <div class="row ">
    <div class="col-6">
    <p class="text-center">Список устройств:</p>
<?php 
$sql = mysqli_query($connect, "SELECT * FROM `device` ");
echo'<div class="row ">';
while($row = mysqli_fetch_array( $sql )) {  
    $show_img = base64_encode($row["photo_device"]);
  echo '<div class="col-6"><div class="card" style="width: 11rem;">
  <img class="card-img-top" src="data:image/jpeg;base64,'.$show_img.'"  alt="Card image cap">
  <div class="card-body">
    <h5 class="card-title">' ;
    echo $row['name_device'] ; 
    echo '</h5>       <p class="card-text">' ;
    echo $row['desc_device'] ;
    echo '</p>   ' ;
  
    echo '   </div>
    </div><br></div>' ;
} 
echo'</div>';
?>



    </div>
    <div class="col-6">
    <p class="text-center">Добавить новое устройство:</p>


    <form class="form-group ml-5 pl-5"  action="add_device.php" method="post" enctype="multipart/form-data">
<label>Название устройства</lable>
<input type="text" class="form-control" name="name_device" placeholder="Введите название"  title="Название устройства">
<label>Описание устройства</lable>
<input type="text" class="form-control" name="desc_device" placeholder="Введите описание"  title="Описание устройства">
<label>Фотография устройств</lable><br>
<input type="file" name="photo_device"><br>
    
    <button class="btn btn-dark" type="submit">Добавить устройство</button>
</form>


    </div>  </div>

    
</div>
<?php require_once 'footer.php';?>
</body>
</html>