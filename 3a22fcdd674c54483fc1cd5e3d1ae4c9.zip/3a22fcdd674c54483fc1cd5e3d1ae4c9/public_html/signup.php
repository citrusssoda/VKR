<?php
session_start(); //запуск сессии
require_once 'connect.php';
//подключение к БД
$login=$_POST['login'];
$password=$_POST['password'];
$password_repeat=$_POST['password_repeat'];
$email=$_POST['email'];
$f_user=$_POST['f_user'];
$i_user=$_POST['i_user'];
$o_user=$_POST['o_user'];
$date=$_POST['date'];
$logincheck = "SELECT * FROM users WHERE `login`=$login";
if (empty($login && $password)) {
    $_SESSION['message']="Не заполнено поле(я)!";//Ошибка
    header('location: reg.php');//Вернуться к регистрации;
}
else{
    //если пароли совпадают,то
    if ($logincheck!=null) {
        if($password === $password_repeat){
            if(empty($f_user && $i_user && $email)){
                $_SESSION['message']="Не заполнено поле(я)!";//Ошибка
                header('location: reg.php');//Вернуться к регистрации;
        }
        else{
            $sql = "INSERT INTO users (`id_user`, `login`,  `password`, `id_role`, `f_user`, `i_user`, `o_user`, `date`, `email`) VALUES (NULL, '$login', '$password', '2', '$f_user', '$i_user', '$o_user', '$date', '$email')";
            $res = mysqli_query($connect, $sql) or die ("Ошибка". mysqli_error($connect));   
            $_SESSION['message']="Вы зарегестрировались!";//вывод сообщения
            header('location: index.php');//Вернуться к входу
        }
       }
      else{
            $_SESSION['message']="Пароли не совпадают!";//Ошибка
       header('location: reg.php');//Вернуться к регистрации;
      }
    }
    else{
        $_SESSION['message']="Логин занят!";//Ошибка
        header('location: reg.php');//Вернуться к регистрации;
    }
}
?>