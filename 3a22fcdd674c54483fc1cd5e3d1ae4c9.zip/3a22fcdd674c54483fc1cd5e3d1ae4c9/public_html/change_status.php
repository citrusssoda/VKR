<?php
session_start(); //запуск сессии
require_once 'connect.php';
//подключение к БД

$seletct_device=$_POST['select_device'];
$status_check  = mysqli_query($connect, "SELECT `connected`.status as status FROM `connected` WHERE `id_device`=$seletct_device");
$status_check = mysqli_fetch_row($status_check)[0];
if($status_check>0){
    $sql = "UPDATE `connected` SET `status` = '0'  WHERE `id_device`='$seletct_device'";
    $res = mysqli_query($connect, $sql) or die ("Ошибка". mysqli_error($connect));   
    $_SESSION['message']="Статус изменён!";//вывод сообщения
    header('location: polz.php');//Вернуться к входу
}
else{
    $sql = "UPDATE `connected` SET `status` = '1'  WHERE `id_device`=$seletct_device";
    $res = mysqli_query($connect, $sql) or die ("Ошибка". mysqli_error($connect));   
    $_SESSION['message']="Статус изменён!";//вывод сообщения
    header('location: polz.php');//Вернуться к входу
}
?>
