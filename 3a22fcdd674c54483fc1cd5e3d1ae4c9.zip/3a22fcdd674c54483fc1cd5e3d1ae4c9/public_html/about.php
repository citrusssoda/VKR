<?php
session_start(); //запуск сессии
require_once 'connect.php';
?><html>
<head>
<meta charset="utf-8">
    <title>Главная</title>  
    <link rel="stylesheet" href="style.css">
    <?php require_once 'header.php';?>
</head>
<body>
    <div class="w-75 p-3 mx-auto my-3" style="background-color: #eee;">
    <h2 class="text-center">О нас</h2>
<hr><h4 class="text-center">Над сайтом работала:</h4>
<p class="text-center">Смирнова С ИС-18<br>☺</p>
<p class="text-center"><a href="presentation.pptx" download>ПРЕЗЕНТАЦИЯ</a>
</div>
<?php require_once 'footer.php';?>
</body>
</html>