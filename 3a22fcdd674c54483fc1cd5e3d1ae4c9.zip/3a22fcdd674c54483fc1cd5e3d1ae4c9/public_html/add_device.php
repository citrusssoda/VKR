<?php
session_start(); //запуск сессии
require_once 'connect.php';
//подключение к БД
$name_device=$_POST['name_device'];
$desc_device=$_POST['desc_device'];
$photo_device=$_FILES['photo_device']['tmp_name'];
if (empty($name_device && $desc_device)) {
    $_SESSION['message']="Не заполнено поле(я)!";//Ошибка
    header('location: admin.php');//Вернуться к регистрации;
}
else{
            $img_type = substr($_FILES['photo_device']['type'],0,5);
            if(!empty($_FILES['photo_device']['tmp_name']) and $img_type=='image')
            {
            $img = addslashes(file_get_contents($_FILES['photo_device']['tmp_name']));
            $sql = "INSERT INTO device (`id_device`, `name_device`,  `desc_device`, `photo_device`) VALUES (NULL, '$name_device', '$desc_device', '$img')";
            $res = mysqli_query($connect, $sql) or die ("Ошибка". mysqli_error($connect));   
            $_SESSION['message']="Устройство добавлено!";//вывод сообщения
            header('location: admin.php');//Вернуться к входу
  }
  else{
      echo "error";
      echo $img;
      echo $photo_device;
  }
}
?>