<?php
session_start(); //запуск сессии
require_once 'connect.php';
?><html>
<head>
<meta charset="utf-8">
    <title>Главная</title>  
    <link rel="stylesheet" href="style.css">
    <?php require_once 'header.php';?>
</head>
<body>
    <div class="w-75 p-3 mx-auto my-3" style="background-color: #eee;">
    <?php
 if(isset($_SESSION['message'])){
     echo '    <p class="msg"> ' . $_SESSION['message'] . '</p>';
 }
 unset($_SESSION['message']);
    ?>
    <h2 class="text-center">Главная</h2><hr>
    <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-50 mx-auto" src="https://lifecontrol.ru/wp-content/uploads/2016/10/Zagorodniy_set.png" alt="First slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-50 mx-auto" src="https://умныйдом-подключ.рф/sites/default/files/images/block/2021-04/camera-smart-home-security.png" alt="Second slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-50 mx-auto" src="https://wo.ua/upload/medialibrary/2ae/xkgqpd28mzfw55hnvrsa2x24k2gvfgx7.png" alt="Third slide">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Назад</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Вперёд</span>
  </a>
</div>
<hr><h4 class="text-center">Умные устройства - в каждый дом</h4>
<p class="text-center">Smart Home – что это значит?

Определение «умный дом» - это заимствованное выражение. Как и многие технологии, в принципе. Эта система пришла к нам с запада. Прежде чем приступить к описанию функций, нюансам управления, рассказам о том, что умеет умный дом, нужно разобраться с понятиями. «Smart Home» в переводе с английского обозначает – «умный дом». Под этой терминологией понимается такое понятие как автоматизация систем быта. Создана система для того, чтобы упростить жизнь нам. Благодаря «умному дому» рутинные задачи больше не приносят раздражения и не вызывают усталость у собственников дома.</p>
</div>
<?php require_once 'footer.php';?>
</body>
</html>