<div class="fixed-bottom bg-dark"><p class="text-center my-2 text-white-50">
  <a href="https://ie-teh.ru/"><img src="teh.png" width="34"></a>ᅠ |ᅠ 
  <a href="https://github.com/citrusssoda"><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/91/Octicons-mark-github.svg/2048px-Octicons-mark-github.svg.png" width="30"></a>ᅠ |ᅠ 
ВКР 2022 год © Смирнова Сᅠ <a  class="text-white" href="https://sun9-31.userapi.com/impg/yWI-1yQhOHFEFioEU81gjzHfEB4SiRZRT079-g/1cnrB5FLKDk.jpg?size=300x265&quality=96&sign=d1974bfe018d41d090ed745cccf96f4b&type=album" title="Это я пишу диплом......">|</a>ᅠᅠ ИС-18</p>
</div>